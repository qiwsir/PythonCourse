#coding:utf-8
'''
    filename: rustspeak.py
'''
class RustSpeak:
    def speak(self):
        return "You don't know me."