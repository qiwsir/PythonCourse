#coding:utf-8
'''
    filename: pythonspeak.py
'''
class PythonSpeak:
    def speak(self):
        return "Life is short. You need Python."